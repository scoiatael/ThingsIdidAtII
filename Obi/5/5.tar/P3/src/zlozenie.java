
public class zlozenie extends Instrukcja {
	Instrukcja A;
	Instrukcja B;
	@Override
	public State wykonaj(State v) throws Exception {
		try
		{
			State s = A.wykonaj(v);
			State s2= B.wykonaj(s);
			return s2;
		}
		catch(Exception str)
		{
			throw str;
		}
	}
	public zlozenie(Instrukcja a, Instrukcja b)
	{
		A=a;
		B=b;
	}

}
