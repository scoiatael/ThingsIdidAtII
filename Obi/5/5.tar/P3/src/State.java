
public class State {
	int[] Zmienne;
	Boolean[] Initialized;
	int size=0;
	public int get (int indeks) throws Exception
	{
		if(indeks<size)
		{
			if(Initialized[indeks])
				return Zmienne[indeks];
			else 
				throw new Exception("variable not initialized");
		}
		else
			throw new Exception("index out of range");
	}
	public void set (int indeks, int zmienna)
	{
		if(size<indeks)
		{
			Zmienne[indeks]=zmienna;
			Initialized[indeks]=true;
		}
		else
		{
			int cur = size*2+1;
			if (indeks>cur)
			{
				cur=indeks;
			}
			int[] temp = new int [cur];
			Boolean[] t2 = new Boolean[cur];
			for(int i=0; i<size;i++)
			{
				temp[i]=Zmienne[i];
				t2[i]=Initialized[i];
			}
			Zmienne=temp;
			Initialized=t2;
			Zmienne[indeks]=zmienna;
			for(int i=size; i<cur;i++)
			{
				Initialized[i]=false;
			}
			Initialized[indeks]=true;
			size=cur;
		}
	}
	public State()
	{
		size=0;
	}
}
