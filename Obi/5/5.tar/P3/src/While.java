
public class While extends Warunek {

	public While(Wyrazenie b, Instrukcja s) {
		super(b, s);
	}
	
	@Override
	public State wykonaj(State v) throws Exception {
		if(Bexp.oblicz(v)==0)
			return v;
		State x = Stm.wykonaj(v);
		return this.wykonaj(x);
	}

}
