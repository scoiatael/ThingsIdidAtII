
public class skip extends Instrukcja {

	@Override
	public State wykonaj(State v) throws Exception {
		return v;
	}
	public skip()
	{}

}
