
public abstract class Instrukcja
{
	public abstract State wykonaj(State v) throws Exception;
}