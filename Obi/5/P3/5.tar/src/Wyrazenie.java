
abstract class Wyrazenie {
	abstract public int oblicz(State V) throws Exception;
}
